//
//  main.cpp
//  Game
//
//  Created by Itamar Jobani on 11/27/16.
//  Copyright © 2016 Itamar Jobani. All rights reserved.
//

#include "game.hpp"

int main( int argc, char* args[] )
{
    //Create a new game
    Game parachutistGame;
    
    //Run game
    parachutistGame.Run();
    
    return 0;
}
